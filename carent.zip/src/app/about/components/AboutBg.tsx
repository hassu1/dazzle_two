import '../about.css'
export default function AboutBg(){
    return(
        <>
            <section className='m-20 b-20' style={{ padding: '200px' , backgroundImage: 'url(/img/about-011.webp)', backgroundSize:'cover',backgroundRepeat:'no-repeat'}}></section>
        </>
    )
}