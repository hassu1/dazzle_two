import OurServicess from "./components/OurServicess";


export default function OurServices(){
    return(
        <>
                <OurServicess />
        </>
    )
}